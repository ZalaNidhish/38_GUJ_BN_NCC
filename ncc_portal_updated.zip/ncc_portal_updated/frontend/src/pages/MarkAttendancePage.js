import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import Sidebar from "../components/Sidebar";
import api from "../utils/api";

const currentYear = new Date().getFullYear();

const getYear = (joiningYear) => {
  if (!joiningYear) return "—";
  const diff = currentYear - parseInt(joiningYear);
  if (diff <= 0) return "1st";
  if (diff === 1) return "2nd";
  if (diff === 2) return "3rd";
  return `${diff + 1}th`;
};

const MarkAttendancePage = () => {
  const { eventId } = useParams();
  const navigate = useNavigate();

  const [event, setEvent]           = useState(null);
  const [cadets, setCadets]         = useState([]);
  const [attendance, setAttendance] = useState({});
  const [loading, setLoading]       = useState(true);
  const [saving, setSaving]         = useState(false);
  const [msg, setMsg]               = useState({ type: "", text: "" });
  const [search, setSearch]         = useState("");

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [eventRes, cadetRes, attendanceRes] = await Promise.all([
          api.get(`/events/${eventId}`),
          api.get("/admin/cadets"),
          api.get(`/attendance/event/${eventId}`),
        ]);

        const ev = eventRes.data;
        setEvent(ev);
        setCadets(cadetRes.data);

        const existingMap = {};
        attendanceRes.data.records.forEach((r) => {
          existingMap[r.cadet._id] = r.status;
        });

        const initial = {};
        cadetRes.data.forEach((cadet) => {
          const uid = cadet.user?._id || cadet.user;
          initial[uid] = existingMap[uid] || "Absent";
        });
        setAttendance(initial);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [eventId]);

  const isFutureEvent = event && new Date(event.startDate) > new Date();

  const toggle = (uid) => {
    setAttendance((prev) => ({
      ...prev,
      [uid]: prev[uid] === "Present" ? "Absent" : "Present",
    }));
  };

  const markAll = (status) => {
    const all = {};
    cadets.forEach((c) => { all[c.user?._id || c.user] = status; });
    setAttendance(all);
  };

  const handleSubmit = async () => {
    setSaving(true);
    setMsg({ type: "", text: "" });
    try {
      await api.post("/attendance/mark", {
        eventId,
        attendance: Object.entries(attendance).map(([cadetId, status]) => ({ cadetId, status })),
      });
      setMsg({ type: "success", text: "Attendance saved successfully!" });
    } catch (err) {
      setMsg({ type: "error", text: err.response?.data?.message || "Failed to save attendance" });
    } finally {
      setSaving(false);
    }
  };

  const filteredCadets = cadets.filter((c) => {
    if (!search) return true;
    const q = search.toLowerCase();
    return (
      c.name?.toLowerCase().includes(q) ||
      c.regimentalNumber?.toLowerCase().includes(q) ||
      getYear(c.joiningYear).toLowerCase().includes(q)
    );
  });

  const presentCount = Object.values(attendance).filter((s) => s === "Present").length;

  if (loading) return (
    <div className="page-layout"><Sidebar /><div className="main-content"><p>Loading...</p></div></div>
  );

  return (
    <div className="page-layout">
      <Sidebar />
      <div className="main-content">
        <div className="page-header flex-between">
          <div>
            <h1>Mark Attendance</h1>
            {event && (
              <p>
                <strong>{event.title}</strong> —{" "}
                {new Date(event.startDate).toLocaleDateString()} to {new Date(event.endDate).toLocaleDateString()}
                {event.location ? ` @ ${event.location}` : ""}
                {event.eventCategory && (
                  <span style={{ marginLeft: 8, padding: "2px 8px", borderRadius: 6, fontSize: 12, fontWeight: 600,
                    background: event.eventCategory === "Parade" ? "#e0f2fe" : "#f0fdf4",
                    color: event.eventCategory === "Parade" ? "#0369a1" : "#15803d" }}>
                    {event.eventCategory}
                  </span>
                )}
              </p>
            )}
          </div>
          <button className="btn btn-ghost" onClick={() => navigate("/attendance")}>← Back</button>
        </div>

        {isFutureEvent && (
          <div className="alert alert-warn">
            This event hasn't started yet ({new Date(event.startDate).toLocaleDateString()}). Attendance cannot be marked for future events.
          </div>
        )}

        {msg.text && <div className={`alert alert-${msg.type}`}>{msg.text}</div>}

        <div className="card">
          <div className="flex-between" style={{ marginBottom: 16 }}>
            <div>
              <span style={{ fontWeight: 600, color: "var(--primary)" }}>
                {presentCount} / {cadets.length} Present
              </span>
              <span style={{ color: "var(--gray)", marginLeft: 8, fontSize: 13 }}>
                ({cadets.length > 0 ? Math.round((presentCount / cadets.length) * 100) : 0}%)
              </span>
            </div>
            {!isFutureEvent && (
              <div className="flex gap-8">
                <button className="btn btn-sm btn-success" onClick={() => markAll("Present")}>✔ All Present</button>
                <button className="btn btn-sm btn-ghost" onClick={() => markAll("Absent")}>✘ All Absent</button>
              </div>
            )}
          </div>

          {/* Single search filter */}
          <div style={{ marginBottom: 16 }}>
            <input
              type="text"
              placeholder="Search by name, reg. no., year..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              style={{ padding: "8px 14px", border: "1.5px solid var(--gray-mid)", borderRadius: 8, fontSize: 14, width: "100%", maxWidth: 340 }}
            />
          </div>

          {filteredCadets.length === 0 ? (
            <p style={{ color: "var(--gray)" }}>No cadets match the search.</p>
          ) : (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>Attendance</th>
                    <th>Name</th>
                    <th>Regimental No.</th>
                    <th>Year</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredCadets.map((cadet) => {
                    const uid = cadet.user?._id || cadet.user;
                    const status = attendance[uid] || "Absent";
                    return (
                      <tr key={cadet._id}>
                        <td>
                          <button
                            onClick={() => !isFutureEvent && toggle(uid)}
                            disabled={isFutureEvent}
                            className="btn btn-sm"
                            style={{
                              background: status === "Present" ? "var(--success)" : "var(--gray-light)",
                              color: status === "Present" ? "white" : "var(--gray)",
                              minWidth: 110,
                              cursor: isFutureEvent ? "not-allowed" : "pointer",
                            }}
                          >
                            {status === "Present" ? "✔ Present" : "✘ Absent"}
                          </button>
                        </td>
                        <td><strong>{cadet.name}</strong></td>
                        <td><code style={{ background: "var(--gray-light)", padding: "2px 8px", borderRadius: 4 }}>{cadet.regimentalNumber}</code></td>
                        <td>{getYear(cadet.joiningYear)}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}

          {cadets.length > 0 && !isFutureEvent && (
            <div className="mt-16">
              <button className="btn btn-primary" onClick={handleSubmit} disabled={saving} style={{ minWidth: 160 }}>
                {saving ? <><span className="spinner" /> Saving...</> : "Save Attendance"}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default MarkAttendancePage;
