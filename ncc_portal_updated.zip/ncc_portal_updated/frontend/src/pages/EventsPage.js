import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Sidebar from "../components/Sidebar";
import { useAuth } from "../context/AuthContext";
import api from "../utils/api";

const EventsPage = () => {
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";

  const [events, setEvents]     = useState([]);
  const [loading, setLoading]   = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving]     = useState(false);
  const [msg, setMsg]           = useState({ type: "", text: "" });

  const [form, setForm] = useState({
    title: "", description: "", type: "Other",
    eventCategory: "Parade",
    startDate: "", endDate: "", location: ""
  });

  const fetchEvents = async () => {
    try {
      const { data } = await api.get("/events");
      setEvents(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchEvents(); }, []);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleCreate = async (e) => {
    e.preventDefault();
    if (new Date(form.endDate) < new Date(form.startDate)) {
      setMsg({ type: "error", text: "End date cannot be before start date" });
      return;
    }
    setSaving(true);
    setMsg({ type: "", text: "" });
    try {
      await api.post("/events", form);
      setMsg({ type: "success", text: "Event created successfully!" });
      setShowForm(false);
      setForm({ title: "", description: "", type: "Other", eventCategory: "Parade", startDate: "", endDate: "", location: "" });
      fetchEvents();
    } catch (err) {
      setMsg({ type: "error", text: err.response?.data?.message || "Failed to create event" });
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Delete this event?")) return;
    try {
      await api.delete(`/events/${id}`);
      setEvents(events.filter((e) => e._id !== id));
    } catch (err) {
      alert("Failed to delete event");
    }
  };

  const isUpcoming = (e) => new Date(e.endDate) >= new Date();

  return (
    <div className="page-layout">
      <Sidebar />
      <div className="main-content">

        <div className="page-header flex-between">
          <div>
            <h1>Events & Camps</h1>
            <p>{isAdmin ? "Create and manage events, mark attendance" : "View NCC events and camps"}</p>
          </div>
          {isAdmin && (
            <button className="btn btn-primary" onClick={() => setShowForm(!showForm)}>
              {showForm ? "Cancel" : "New Event"}
            </button>
          )}
        </div>

        {msg.text && <div className={`alert alert-${msg.type}`}>{msg.text}</div>}

        {/* Create Event Form (admin only) */}
        {isAdmin && showForm && (
          <div className="card">
            <h2 style={{ marginBottom: 16 }}>Create New Event</h2>
            <form onSubmit={handleCreate}>
              <div className="form-row">
                <div className="form-group">
                  <label>Title *</label>
                  <input name="title" value={form.title} onChange={handleChange} required placeholder="Event title" />
                </div>
                <div className="form-group">
                  <label>Type</label>
                  <select name="type" value={form.type} onChange={handleChange}>
                    <option>Camp</option>
                    <option>Parade</option>
                    <option>Training</option>
                    <option>Competition</option>
                    <option>Other</option>
                  </select>
                </div>
                <div className="form-group">
                  <label>Attendance Category</label>
                  <select name="eventCategory" value={form.eventCategory} onChange={handleChange}>
                    <option value="Parade">Parade</option>
                    <option value="Extra Event">Extra Event</option>
                  </select>
                </div>
              </div>
              <div className="form-group">
                <label>Description</label>
                <textarea name="description" value={form.description} onChange={handleChange} rows={2} />
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label>Start Date *</label>
                  <input type="date" name="startDate" value={form.startDate} onChange={handleChange} required />
                </div>
                <div className="form-group">
                  <label>End Date *</label>
                  <input type="date" name="endDate" value={form.endDate} onChange={handleChange} required />
                </div>
              </div>
              <div className="form-group">
                <label>Location</label>
                <input name="location" value={form.location} onChange={handleChange} placeholder="e.g. NCC Training Camp, Lucknow" />
              </div>
              <button type="submit" className="btn btn-primary" disabled={saving}>
                {saving ? <><span className="spinner" /> Creating...</> : "🗓️ Create Event"}
              </button>
            </form>
          </div>
        )}

        {/* Events Table */}
        <div className="card">
          {loading ? <p>Loading events...</p> : events.length === 0 ? (
            <p style={{ color: "var(--gray)", textAlign: "center", padding: 20 }}>No events found.</p>
          ) : (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>Event</th>
                    <th>Type</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Location</th>
                    <th>Status</th>
                    {isAdmin && <th>Actions</th>}
                  </tr>
                </thead>
                <tbody>
                  {events.map((e) => (
                    <tr key={e._id}>
                      <td>
                        <strong>{e.title}</strong>
                        {e.description && (
                          <p style={{ fontSize: 12, color: "var(--gray)", marginTop: 2 }}>
                            {e.description.substring(0, 60)}
                          </p>
                        )}
                      </td>
                      <td><span className={`badge badge-${e.type?.toLowerCase()}`}>{e.type}</span></td>
                      <td>{new Date(e.startDate).toLocaleDateString()}</td>
                      <td>{new Date(e.endDate).toLocaleDateString()}</td>
                      <td>{e.location || "—"}</td>
                      <td>
                        <span className="badge" style={{
                          background: isUpcoming(e) ? "#d1fae5" : "#f3f4f6",
                          color: isUpcoming(e) ? "#065f46" : "#6b7280"
                        }}>
                          {isUpcoming(e) ? "Upcoming" : "Completed"}
                        </span>
                      </td>
                      {isAdmin && (
                        <td>
                          <div className="flex gap-8">
                            <Link to={`/mark-attendance/${e._id}`} className="btn btn-gold btn-sm">
                              Attendance
                            </Link>
                            <button
                              className="btn btn-danger btn-sm"
                              onClick={() => handleDelete(e._id)}
                            >
                              Delete
                            </button>
                          </div>
                        </td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};

export default EventsPage;
