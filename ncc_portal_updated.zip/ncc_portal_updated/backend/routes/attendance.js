const express = require("express");
const router = express.Router();
const Attendance = require("../models/Attendance");
const Event = require("../models/Event");
const { protect, adminOnly } = require("../middleware/auth");

// @route   GET /api/attendance/my
// @desc    Get all events a cadet attended
// @access  Private
router.get("/my", protect, async (req, res) => {
  try {
    const records = await Attendance.find({ cadet: req.user._id })
      .populate("event", "title type startDate endDate location eventCategory")
      .sort({ createdAt: -1 });
    res.json(records);
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
});

// @route   GET /api/attendance/event/:eventId
// @desc    Get attendance sheet for a specific event
// @access  Private (admin only)
router.get("/event/:eventId", protect, adminOnly, async (req, res) => {
  try {
    const event = await Event.findById(req.params.eventId);
    if (!event) return res.status(404).json({ message: "Event not found" });

    const records = await Attendance.find({ event: req.params.eventId })
      .populate("cadet", "regimentalNumber")
      .populate("markedBy", "regimentalNumber")
      .sort({ createdAt: 1 });

    res.json({ event, records });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
});

// @route   GET /api/attendance/all-events
// @desc    Get all events with attendance status (admin) - for viewing/editing past attendance
// @access  Private (admin only)
router.get("/all-events", protect, adminOnly, async (req, res) => {
  try {
    const today = new Date();
    today.setHours(23, 59, 59, 999);

    // Get all events up to today
    const events = await Event.find({ startDate: { $lte: today } }).sort({ startDate: -1 });

    // Get attendance count for each event
    const result = await Promise.all(
      events.map(async (ev) => {
        const total = await Attendance.countDocuments({ event: ev._id });
        const present = await Attendance.countDocuments({ event: ev._id, status: "Present" });
        return {
          _id: ev._id,
          title: ev.title,
          type: ev.type,
          startDate: ev.startDate,
          endDate: ev.endDate,
          location: ev.location,
          attendanceMarked: total > 0,
          presentCount: present,
          totalMarked: total,
        };
      })
    );

    res.json(result);
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
});

// @route   POST /api/attendance/mark
// @desc    Mark or update attendance for multiple cadets in an event
// @access  Private (admin only)
// Body: { eventId, attendance: [{ cadetId, status }] }
router.post("/mark", protect, adminOnly, async (req, res) => {
  const { eventId, attendance } = req.body;

  if (!eventId || !Array.isArray(attendance) || attendance.length === 0)
    return res.status(400).json({ message: "Event ID and attendance list are required" });

  try {
    const event = await Event.findById(eventId);
    if (!event) return res.status(404).json({ message: "Event not found" });

    // Restrict marking attendance for future events
    const today = new Date();
    if (new Date(event.startDate) > today) {
      return res.status(400).json({ message: "Cannot mark attendance for future events" });
    }

    const operations = attendance.map(({ cadetId, status }) => ({
      updateOne: {
        filter: { event: eventId, cadet: cadetId },
        update: {
          $set: {
            status: status || "Absent",
            markedBy: req.user._id,
          },
        },
        upsert: true,
      },
    }));

    await Attendance.bulkWrite(operations);
    res.json({ message: `Attendance marked for ${attendance.length} cadet(s)` });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
});

// @route   GET /api/attendance/summary/:cadetId
// @desc    Get attendance summary for a cadet (admin view) — splits parade vs extra event
// @access  Private (admin only)
router.get("/summary/:cadetId", protect, adminOnly, async (req, res) => {
  try {
    const records = await Attendance.find({ cadet: req.params.cadetId })
      .populate("event", "title type startDate eventCategory")
      .sort({ createdAt: -1 });

    const paradeRecords = records.filter((r) => !r.event?.eventCategory || r.event.eventCategory === "Parade");
    const extraRecords  = records.filter((r) => r.event?.eventCategory === "Extra Event");

    const paradeTotal   = paradeRecords.length;
    const paradePresent = paradeRecords.filter((r) => r.status === "Present").length;
    const extraTotal    = extraRecords.length;
    const extraPresent  = extraRecords.filter((r) => r.status === "Present").length;
    const total         = paradeTotal + extraTotal;
    const present       = paradePresent + extraPresent;

    res.json({
      total,
      present,
      absent: total - present,
      percentage: total > 0 ? ((present / total) * 100).toFixed(1) : 0,
      paradeTotal,
      paradePresent,
      paradeAbsent: paradeTotal - paradePresent,
      paradePct: paradeTotal > 0 ? ((paradePresent / paradeTotal) * 100).toFixed(1) : 0,
      extraTotal,
      extraPresent,
      extraAbsent: extraTotal - extraPresent,
      extraPct: extraTotal > 0 ? ((extraPresent / extraTotal) * 100).toFixed(1) : 0,
      records,
    });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
});

module.exports = router;
