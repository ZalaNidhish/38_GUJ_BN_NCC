const mongoose = require("mongoose");

const eventSchema = new mongoose.Schema(
  {
    // Event title (e.g., "Annual Training Camp 2024")
    title: { type: String, required: true, trim: true },

    description: { type: String, trim: true },

    // Event type
    type: {
      type: String,
      enum: ["Camp", "Parade", "Training", "Competition", "Other"],
      default: "Other",
    },

    // Attendance category — used to split parade vs extra-event attendance
    eventCategory: {
      type: String,
      enum: ["Parade", "Extra Event"],
      default: "Parade",
    },

    // Date range
    startDate: { type: Date, required: true },
    endDate:   { type: Date, required: true },

    location: { type: String, trim: true },

    // Admin who created this event
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Event", eventSchema);
