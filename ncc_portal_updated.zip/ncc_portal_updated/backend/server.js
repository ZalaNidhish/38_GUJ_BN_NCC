const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
require("dotenv").config();

const app = express();

// Middleware
app.use(cors());                        // Allow cross-origin requests (React frontend)
app.use(express.json());               // Parse incoming JSON requests

// Route imports
const authRoutes     = require("./routes/auth");
const cadetRoutes    = require("./routes/cadet");
const adminRoutes    = require("./routes/admin");
const eventRoutes    = require("./routes/event");
const noticeRoutes   = require("./routes/notice");
const attendanceRoutes = require("./routes/attendance");

// Mount routes
app.use("/api/auth",       authRoutes);
app.use("/api/cadet",      cadetRoutes);
app.use("/api/admin",      adminRoutes);
app.use("/api/events",     eventRoutes);
app.use("/api/notices",    noticeRoutes);
app.use("/api/attendance", attendanceRoutes);

// Health check
app.get("/", (req, res) => res.send("NCC Portal API running"));

// Connect to MongoDB and start server
const PORT = process.env.PORT || 5000;

mongoose
  .connect(process.env.MONGO_URI)
  .then(() => {
    console.log("MongoDB connected");
    app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
  })
  .catch((err) => console.error("MongoDB connection error:", err));
